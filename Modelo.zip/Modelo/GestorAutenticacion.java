package Modelo;

public class GestorAutenticacion {
    private static GestorAutenticacion instancia;

    public static GestorAutenticacion nuevoGestor(){
        if (instancia == null) {
            instancia = new GestorAutenticacion();
        }
        return instancia;
    }
    
    private GestorAutenticacion() {}
    
    public boolean validarSesion(String numCuenta, String pinSeguridad, Cuenta cuenta) {
        boolean coincideNumero = numCuenta.equals(cuenta.getNumeroCuenta());
        boolean coincidePin = pinSeguridad.equals(cuenta.getPinSeguridad());
        return  coincideNumero && coincidePin;
    }
    
    public static void elimniarGestor() {
        instancia = null;
    }
}
