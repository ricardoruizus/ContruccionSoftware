package Modelo;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;


public class ConexionSql {
    private final String URL = "jdbc:mysql://localhost:3306/usuarios";
    private final String USUARIO = "root";
    private static ConexionSql instancia;
    
    private ConexionSql() {
        try {
            getConexion();
        } catch (SQLException expected) {
            System.out.println("Error al conectar: " + expected.getMessage());
        }
    }
    
    public static ConexionSql nuevaConexion() {
        if (instancia == null) {
            instancia = new ConexionSql();
        }
        return instancia;
    }
    
    private Connection getConexion() throws SQLException {
        return DriverManager.getConnection(this.URL, this.USUARIO, "");
    }
    
    private Statement getDeclaracion() throws SQLException {
        return getConexion().createStatement();
    }
    
    public boolean existeUsuario(String numeroUsuario) throws SQLException {
        String sentenciaSQL =  "SELECT no_cuenta"
                + "             FROM datos_cuenta "
                + "             WHERE no_cuenta = " + numeroUsuario + ";";
        ResultSet consultaSQL = getDeclaracion().executeQuery(sentenciaSQL);
        return consultaSQL.next();
    }
    
    private Cuenta cuentaGenerada(ResultSet consulta) throws SQLException {
        String noCuenta = consulta.getString("no_cuenta");
        Nombre nombre = new Nombre(consulta.getString("nombre"));
        String pinSeguridad = consulta.getString("pin_seguridad");
        double saldoCuenta = consulta.getFloat("saldo_cuenta");

        DatosCuenta datos = new DatosCuenta(noCuenta, nombre, pinSeguridad);
        return new Cuenta(datos, saldoCuenta);
    }
    
    public Cuenta getUsuarios(String numeroCuenta) throws SQLException {
        if (existeUsuario(numeroCuenta)) {
            String sentenciaSQL = "SELECT no_cuenta, "
                    + "                    nombre, "
                    + "                    fecha_nacimiento, "
                    + "                    AES_DECRYPT(rfc, 'Katniss')AS rfc, "
                    + "                    AES_DECRYPT(pin_seguridad, 'Katniss') AS pin_seguridad, "
                    + "                    saldo_cuenta "
                    + "             FROM datos_cuenta "
                    + "             WHERE no_cuenta = " + numeroCuenta + ";";
            ResultSet consultaSQL = getDeclaracion().executeQuery(sentenciaSQL);
            consultaSQL.next();
            return cuentaGenerada(consultaSQL);
        } else {
            System.out.println("Número de cuenta desconocido");
            return null;
        }
    }
    
    public void actualizarSaldo(Cuenta cuenta) {
        String sentenciaSQL = "UPDATE datos_cuenta "
                + "             SET saldo_cuenta = ?"
                + "             WHERE no_cuenta = " + cuenta.getDatosCuenta().getIdCuenta() + ";";
        PreparedStatement editarSQL;
        try {
            editarSQL = getConexion().prepareStatement(sentenciaSQL);
            editarSQL.setFloat(1, (float) cuenta.getSaldoCuenta());
            editarSQL.executeUpdate();
        } catch (SQLException ok) {
            Logger.getLogger(ConexionSql.class.getName()).log(Level.SEVERE, null, ok);
        }
    }
}

