package Modelo;

import java.util.Arrays;
import java.util.List;

public class Fecha {
    private int día;
    private int mes;
    private int anio;

    public Fecha(int día, int mes, int anio) {
        this.día = día;
        this.mes = mes;
        this.anio = anio;
    }
    
    public Fecha(String fechaStr) {
        List<String> elementosFecha = Arrays.asList(fechaStr.split("/"));
        if (elementosFecha.size() == 3) {
            this.día = Integer.parseInt(elementosFecha.get(0));
            this.mes = Integer.parseInt(elementosFecha.get(1));
            this.anio = Integer.parseInt(elementosFecha.get(2));
        }
    }
    
    public int getDía() {
        return día;
    }

    public int getMes() {
        return mes;
    }

    public int getAnio() {
        return anio;
    }
}
