package Modelo;

import java.util.Arrays;
import java.util.List;

public class Nombre {
    private String primer_nombre;
    private String segundo_nombre;
    private String apellido_p;
    private String apellido_m;

    public Nombre(
            String primer_nombre, 
            String segundo_nombre, 
            String apellido_p, 
            String apellido_m) {
        this.primer_nombre = primer_nombre;
        this.segundo_nombre = segundo_nombre;
        this.apellido_p = apellido_p;
        this.apellido_m = apellido_m;
    }
    
    public Nombre(String nombreStr) {
        List<String> elementosNombre = Arrays.asList(nombreStr.split(" "));
        if (elementosNombre.size() == 4) {
            this.primer_nombre = elementosNombre.get(0);
            this.segundo_nombre = elementosNombre.get(1);
            this.apellido_p = elementosNombre.get(2);
            this.apellido_m = elementosNombre.get(3);
        }
    }

    public String getPrimer_nombre() {
        return primer_nombre;
    }

    public String getSegundo_nombre() {
        return segundo_nombre;
    }

    public String getApellido_p() {
        return apellido_p;
    }

    public String getApellido_m() {
        return apellido_m;
    }
}
