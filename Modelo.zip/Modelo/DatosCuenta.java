package Modelo;

import java.util.Random;

public class DatosCuenta {
    private final String noCuenta;
    private final Nombre nombreBeneficiario;
    private Fecha fechaNacimiento;
    private String rfc;
    private final String pinSeguridad;

    public DatosCuenta(
            Nombre nombreBeneficiario, 
            Fecha fechaNacimiento, 
            String rfc, 
            String pinSeguridad) {
        this.noCuenta = generarNoCuenta();
        this.nombreBeneficiario = nombreBeneficiario;
        this.pinSeguridad = pinSeguridad;
    }

    public DatosCuenta(String noCuenta, Nombre nombreBeneficiario, String pinSeguridad) {
        this.noCuenta = noCuenta;
        this.nombreBeneficiario = nombreBeneficiario;
        this.pinSeguridad = pinSeguridad;
    }

    public String getIdCuenta() {
        return noCuenta;
    }

    public Nombre getNombreBeneficiario() {
        return nombreBeneficiario;
    }

    public String getPinSeguridad() {
        return pinSeguridad;
    }
    
    private String generarNoCuenta() {
        String cadenaId = "";
        Random random = new Random();
        int LONGITUD_ID = 8;
        for (int i=1; i <= LONGITUD_ID; i++) {
            int numeroAgregado = random.nextInt(10);
            cadenaId = cadenaId + Integer.toString(numeroAgregado);
        }
        return cadenaId;
    }
}
